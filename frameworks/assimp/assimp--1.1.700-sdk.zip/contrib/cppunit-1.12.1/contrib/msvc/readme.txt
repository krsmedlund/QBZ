What's in those files:

	* CppUnit.WWTpl: a template Workspace Whiz! which create a new class 
and add the new files to the project. You can specify that the class is a 
CppUnit testcase and all the macro will be defined to register the test case
and declare the test suite. Workspace Whiz! is an add-ins for VC++. It can
be found at: http://www.workspacewhiz.com/.

	* AddingUnitTestMethod.dsm: a set of VC++ macro to add unit test
using helper macros.